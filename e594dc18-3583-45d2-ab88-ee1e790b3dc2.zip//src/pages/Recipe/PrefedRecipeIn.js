import RecipeProfile from "../../components/Recipe/RecipeProfile";

const PrefedRecipeIn = () => {
  return (
    <>
      <RecipeProfile />
    </>
  );
};

export default PrefedRecipeIn;
