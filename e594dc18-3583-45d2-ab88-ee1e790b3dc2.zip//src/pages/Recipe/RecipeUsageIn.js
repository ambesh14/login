import RecipeModel from "../../Reuseable/RecipeModel";

const RecipeUsageIn = () => {
  return (
    <>
      <RecipeModel />
    </>
  );
};

export default RecipeUsageIn;
