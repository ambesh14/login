const ServiceWarranty = () => {
  return (
    <>
      <h1>ServiceWarranty</h1>
    </>
  );
};

export default ServiceWarranty;
