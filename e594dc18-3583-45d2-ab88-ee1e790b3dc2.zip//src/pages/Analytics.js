const Analytics = () => {
  return (
    <>
      <h1>Analytics</h1>
    </>
  );
};

export default Analytics;
