const Order = () => {
  return (
    <>
      <h1>Order</h1>
    </>
  );
};

export default Order;
