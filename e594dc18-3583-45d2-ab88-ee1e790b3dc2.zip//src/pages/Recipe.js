import Recipein from "../components/Recipe/Recipein";
// import Typography from "@mui/material/Typography";
const Recipe = () => {
  return (
    <>
      {/* <Typography sx={{ m: 1, color: "#000", textAlign: "left" }} variant="h4">
        Recipe
      </Typography> */}
      <Recipein />
    </>
  );
};

export default Recipe;
