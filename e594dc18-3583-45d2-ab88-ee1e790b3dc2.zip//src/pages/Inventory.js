const Inventory = () => {
  return (
    <>
      <h1>Inventory</h1>
    </>
  );
};

export default Inventory;
