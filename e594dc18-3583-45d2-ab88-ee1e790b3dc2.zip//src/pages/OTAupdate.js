const OTAupdate = () => {
  return (
    <>
      <h1>OTA Update</h1>
    </>
  );
};
export default OTAupdate;
