import MachineTable from "../components/Machine/MachineTable";
// import Typography from "@mui/material/Typography";
const Machine = () => {
  return (
    <>
      {/* <Typography sx={{ m: 1, color: "#000", textAlign: "left" }} variant="h4">
        Machine
      </Typography> */}
      <MachineTable />
    </>
  );
};

export default Machine;
