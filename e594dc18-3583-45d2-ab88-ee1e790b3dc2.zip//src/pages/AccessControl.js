const AccessControl = () => {
  return (
    <>
      <h1>Access Control</h1>
    </>
  );
};

export default AccessControl;
