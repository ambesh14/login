import ComplaintTab from "../../../Reuseable/Tabs/ComplaintTab";

const Complaints = () => {
  return (
    <>
      <ComplaintTab />
    </>
  );
};

export default Complaints;
