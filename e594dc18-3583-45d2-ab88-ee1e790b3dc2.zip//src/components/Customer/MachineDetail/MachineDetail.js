import MachineTab from "../../../Reuseable/Tabs/MachineTab";

const MachineDetail = () => {
  return (
    <>
      <MachineTab />
    </>
  );
};

export default MachineDetail;
