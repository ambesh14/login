import RecipeTab from "./../../Reuseable/Tabs/RecipeTab";
const Recipein = () => {
  return (
    <>
      <RecipeTab sx={{ background: "#f2f2f2" }} />
    </>
  );
};

export default Recipein;
